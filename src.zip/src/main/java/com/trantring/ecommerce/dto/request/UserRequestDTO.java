package com.trantring.ecommerce.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRequestDTO {
    String password;
    String firstName;
    String lastName;
}
